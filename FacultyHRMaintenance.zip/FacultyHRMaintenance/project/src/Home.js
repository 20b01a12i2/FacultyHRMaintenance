import React from 'react';
import './App.css';
import './image1.css';
const Home = () => {
    return (
        <div class="container">
            
        </div>
    );
};

export default Home;